#include <windows.h>

main()
{
	//system("code\\xulrunner-win32\\xulrunner.exe code\\application.ini");
	WinExec("code\\xulrunner-win32\\xulrunner.exe code\\application.ini", SW_SHOW);
}