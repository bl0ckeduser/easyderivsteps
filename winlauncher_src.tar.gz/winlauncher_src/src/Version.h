

#ifndef VERSION_H
#define VERSION_H

	#define RC_FILEVERSION 1,0,0,0
	#define RC_FILEVERSION_STRING "1, 0, 0, 0\0"
	static const char FULLVERSION_STRING[] = "1.0.0.0";
	

#endif //VERSION_h
